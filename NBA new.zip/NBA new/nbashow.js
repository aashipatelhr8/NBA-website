function VandM1(){
	if(document.getElementById("CAyesCheck1").checked){
		document.getElementById("CAifYes1").style.display ="block";
	}
	else{
		document.getElementById("CAifYes1").style.display ="none";
	}
}
function check1_1(){
	if(document.getElementById("check1_1").checked){
		document.getElementById("check1_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check1_1ifyes").style.display="none";
	}
}
function check1_2(){
	if(document.getElementById("check1_2").checked){
		document.getElementById("check1_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check1_2ifyes").style.display="none";
	}
}
function check1_3(){
	if(document.getElementById("check1_3").checked){
		document.getElementById("check1_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check1_3ifyes").style.display="none";
	}
}
/* programme educational objective start*/
function PEO(){
	debugger;
	if(document.getElementById("PEOyesCheck2").checked){
		document.getElementById("PEOifYes2").style.display ="block";
	}
	else{
		document.getElementById("PEOifYes2").style.display ="none";
	}}
	function check2_1(){
	if(document.getElementById("check2_1").checked){
		document.getElementById("check2_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check2_1ifyes").style.display="none";
	}}
function check2_2(){
	if(document.getElementById("check2_2").checked){
		document.getElementById("check2_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check2_2ifyes").style.display="none";
	}}
	
	function check2_3(){
	if(document.getElementById("check2_3").checked){
		document.getElementById("check2_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check2_3ifyes").style.display="none";
	}}
	function check2_4(){
	if(document.getElementById("check2_4").checked){
		document.getElementById("check2_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check2_4ifyes").style.display="none";
	}}
	function check2_5(){
	if(document.getElementById("check2_5").checked){
		document.getElementById("check2_5ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check2_5ifyes").style.display="none";
	}}
	/*PEO ends here*/
	function AofPEO(){
	debugger;
	if(document.getElementById("APEOyesCheck2").checked){
		document.getElementById("APEOifYes2").style.display ="block";
	}
	else{
		document.getElementById("APEOifYes2").style.display ="none";
	}}
	function check3_1(){
	if(document.getElementById("check3_1").checked){
		document.getElementById("check3_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check3_1ifyes").style.display="none";
	}}
function check3_2(){
	if(document.getElementById("check3_2").checked){
		document.getElementById("check3_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check3_2ifyes").style.display="none";
	}}
	/* achievement of PEO ends here*/
	/*assessment of APEO starts here*/
	function AAofPEO(){
	debugger;
	if(document.getElementById("AAPEOyesCheck2").checked){
		document.getElementById("AAPEOifYes2").style.display ="block";
	}
	else{
		document.getElementById("AAPEOifYes2").style.display ="none";
	}}
	function check4_1(){
	if(document.getElementById("check4_1").checked){
		document.getElementById("check4_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check4_1ifyes").style.display="none";
	}}
function check4_2(){
	if(document.getElementById("check4_2").checked){
		document.getElementById("check4_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check4_2ifyes").style.display="none";
	}}
function IPEOR(){
	debugger;
	if(document.getElementById("IPEORyesCheck2").checked){
		document.getElementById("IPEORifYes2").style.display ="block";
	}
	else{
		document.getElementById("IPEORifYes2").style.display ="none";
	}}
	function check5_1(){
	if(document.getElementById("check5_1").checked){
		document.getElementById("check5_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check5_1ifyes").style.display="none";
	}}
	/*criterion 2 starts here*/
	function DVOC(){
	if(document.getElementById("DVOCyesCheck1").checked){
		document.getElementById("DVOCifYes1").style.display ="block";
	}
	else{
		document.getElementById("DVOCifYes1").style.display ="none";
	}}
	function check11_1(){
	if(document.getElementById("check11_1").checked){
		document.getElementById("check11_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check11_1ifyes").style.display="none";
	}}
function check11_2(){
	if(document.getElementById("check11_2").checked){
		document.getElementById("check11_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check11_2ifyes").style.display="none";
	}}
	
	function check11_3(){
	if(document.getElementById("check11_3").checked){
		document.getElementById("check11_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check11_3ifyes").style.display="none";
	}}
	function check11_4(){
	if(document.getElementById("check11_4").checked){
		document.getElementById("check11_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check11_4ifyes").style.display="none";
	}}
	function check11_5(){
	if(document.getElementById("check11_5").checked){
		document.getElementById("check11_5ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check11_5ifyes").style.display="none";
	}}
	function APO(){
	if(document.getElementById("APOyesCheck1").checked){
		document.getElementById("APOifYes1").style.display ="block";
	}
	else{
		document.getElementById("APOifYes1").style.display ="none";
	}}
	function check12_1(){
	if(document.getElementById("check12_1").checked){
		document.getElementById("check12_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check12_1ifyes").style.display="none";
	}}
function check12_2(){
	if(document.getElementById("check12_2").checked){
		document.getElementById("check12_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check12_2ifyes").style.display="none";
	}}
	
	function check12_3(){
	if(document.getElementById("check12_3").checked){
		document.getElementById("check12_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check12_3ifyes").style.display="none";
	}}
	function check12_4(){
	if(document.getElementById("check12_4").checked){
		document.getElementById("check12_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check12_4ifyes").style.display="none";
	}}
	function EAPO(){
	if(document.getElementById("EAPOyesCheck1").checked){
		document.getElementById("EAPOifYes1").style.display ="block";
	}
	else{
		document.getElementById("EAPOifYes1").style.display ="none";
	}}
	function check13_1(){
	if(document.getElementById("check13_1").checked){
		document.getElementById("check13_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check13_1ifyes").style.display="none";
	}}
function check13_2(){
	if(document.getElementById("check13_2").checked){
		document.getElementById("check13_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check13_2ifyes").style.display="none";
	}}
	function UEAPO(){
	if(document.getElementById("UEAPOyesCheck1").checked){
		document.getElementById("UEAPOifYes1").style.display ="block";
	}
	else{
		document.getElementById("UEAPOifYes1").style.display ="none";
	}}
	function check14_1(){
	if(document.getElementById("check14_1").checked){
		document.getElementById("check14_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check14_1ifyes").style.display="none";
	}}
function check14_2(){
	if(document.getElementById("check14_2").checked){
		document.getElementById("check14_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check14_2ifyes").style.display="none";
	}}
	function check14_3(){
	if(document.getElementById("check14_3").checked){
		document.getElementById("check14_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check14_3ifyes").style.display="none";
	}}
	
	function CURRICULUM(){
	if(document.getElementById("CURRICULUMyesCheck1").checked){
		document.getElementById("CURRICULUMifYes1").style.display ="block";
	}
	else{
		document.getElementById("CURRICULUMifYes1").style.display ="none";
	}}
	function check21_1(){
	if(document.getElementById("check21_1").checked){
		document.getElementById("check21_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check21_1ifyes").style.display="none";
	}}
function check21_2(){
	if(document.getElementById("check21_2").checked){
		document.getElementById("check21_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check21_2ifyes").style.display="none";
	}}
	function check21_3(){
	if(document.getElementById("check21_3").checked){
		document.getElementById("check21_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check21_3ifyes").style.display="none";
	}}
	function CURRICOMP(){
	if(document.getElementById("CURRICOMPyesCheck1").checked){
		document.getElementById("CURRICOMPifYes1").style.display ="block";
	}
	else{
		document.getElementById("CURRICOMPifYes1").style.display ="none";
	}}
	function check22_1(){
	if(document.getElementById("check22_1").checked){
		document.getElementById("check22_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check22_1ifyes").style.display="none";
	}}
	function III(){
	if(document.getElementById("IIIyesCheck1").checked){
		document.getElementById("IIIifYes1").style.display ="block";
	}
	else{
		document.getElementById("IIIifYes1").style.display ="none";
	}}
	function check23_1(){
	if(document.getElementById("check23_1").checked){
		document.getElementById("check23_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check23_1ifyes").style.display="none";
	}}
function CURRIDEVELOP(){
	if(document.getElementById("CURRIDEVELOPyesCheck1").checked){
		document.getElementById("CURRIDEVELOPifYes1").style.display ="block";
	}
	else{
		document.getElementById("CURRIDEVELOPifYes1").style.display ="none";
	}}
	function check24_1(){
	if(document.getElementById("check24_1").checked){
		document.getElementById("check24_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check24_1ifyes").style.display="none";
	}}
function check24_2(){
	if(document.getElementById("check24_2").checked){
		document.getElementById("check24_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check24_2ifyes").style.display="none";
	}}
function COURSE(){
	if(document.getElementById("COURSEyesCheck1").checked){
		document.getElementById("COURSEifYes1").style.display ="block";
	}
	else{
		document.getElementById("COURSEifYes1").style.display ="none";
	}}
	function check25_1(){
	if(document.getElementById("check25_1").checked){
		document.getElementById("check25_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check25_1ifyes").style.display="none";
	}}
	/*criterion 4*/
	function check41_1(){
	if(document.getElementById("check41_1").checked){
		document.getElementById("check41_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check41_1ifyes").style.display="none";
	}}
	function check41_11(){
	if(document.getElementById("check41_11").checked){
		document.getElementById("check41_11ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check41_11ifyes").style.display="none";
	}}
	function check41_12(){
	if(document.getElementById("check41_12").checked){
		document.getElementById("check41_12ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check41_12ifyes").style.display="none";
	}}
	function check41_13(){
	if(document.getElementById("check41_13").checked){
		document.getElementById("check41_13ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check41_13ifyes").style.display="none";
	}}
	function check42_1(){
	if(document.getElementById("check42_1").checked){
		document.getElementById("check42_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check42_1ifyes").style.display="none";
	}}
	function check42_11(){
	if(document.getElementById("check42_11").checked){
		document.getElementById("check42_11ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check42_11ifyes").style.display="none";
	}}
	function check42_12(){
	if(document.getElementById("check42_12").checked){
		document.getElementById("check42_12ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check42_12ifyes").style.display="none";
	}}
	function check42_13(){
	if(document.getElementById("check42_13").checked){
		document.getElementById("check42_13ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check42_13ifyes").style.display="none";
	}}
	/*POINT 2 SUCCESS RATE*/
	function SRshow(){
	if(document.getElementById("SRshowyesCheck1").checked){
		document.getElementById("SRshowifYes1").style.display ="block";
	}
	else{
		document.getElementById("SRshowifYes1").style.display ="none";
	}}
	function check421_1(){
	if(document.getElementById("check421_1").checked){
		document.getElementById("check421_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check421_1ifyes").style.display="none";
	}}
	function check422_1(){
	if(document.getElementById("check422_1").checked){
		document.getElementById("check422_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check422_1ifyes").style.display="none";
	}}
	function check423_1(){
	if(document.getElementById("check423_1").checked){
		document.getElementById("check423_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check423_1ifyes").style.display="none";
	}}
	/*POINT 3*/
	function APERFORM(){
	if(document.getElementById("APERFORMyesCheck1").checked){
		document.getElementById("APERFORMifYes1").style.display ="block";
	}
	else{
		document.getElementById("APERFORMifYes1").style.display ="none";
	}}
	function check431_1(){
	if(document.getElementById("check431_1").checked){
		document.getElementById("check431_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check431_1ifyes").style.display="none";
	}}
	function check432_1(){
	if(document.getElementById("check432_1").checked){
		document.getElementById("check432_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check432_1ifyes").style.display="none";
	}}
	function check433_1(){
	if(document.getElementById("check433_1").checked){
		document.getElementById("check433_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check433_1ifyes").style.display="none";
	}}
	/*POINT 4*/
	function PLACEMENT(){
	if(document.getElementById("PLACEMENTyesCheck1").checked){
		document.getElementById("PLACEMENTifYes1").style.display ="block";
	}
	else{
		document.getElementById("PLACEMENTifYes1").style.display ="none";
	}}
	
	function PA(){
	if(document.getElementById("PAyesCheck1").checked){
		document.getElementById("PAifYes1").style.display ="block";
	}
	else{
		document.getElementById("PAifYes1").style.display ="none";
	}}
	function check45_1(){
	if(document.getElementById("check45_1").checked){
		document.getElementById("check45_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check45_1ifyes").style.display="none";
	}}
	function check45_5(){
	if(document.getElementById("check45_5").checked){
		document.getElementById("check45_5ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check45_5ifyes").style.display="none";
	}}function check45_2(){
	if(document.getElementById("check45_2").checked){
		document.getElementById("check45_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check45_2ifyes").style.display="none";
	}}function check45_3(){
	if(document.getElementById("check45_3").checked){
		document.getElementById("check45_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check45_3ifyes").style.display="none";
	}}function check45_4(){
	if(document.getElementById("check45_4").checked){
		document.getElementById("check45_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check45_4ifyes").style.display="none";
	}}
	/*CRITERION 4 ENDS HERE
	CRITERION 5 STARTS HERE*/
	function STRSHOW(){
	if(document.getElementById("STRSHOWyesCheck1").checked){
		document.getElementById("STRSHOWifYes1").style.display ="block";
	}
	else{
		document.getElementById("STRSHOWifYes1").style.display ="none";
	}}
	function check511_1(){
	if(document.getElementById("check511_1").checked){
		document.getElementById("check511_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check511_1ifyes").style.display="none";
	}}
	function check512_1(){
	if(document.getElementById("check512_1").checked){
		document.getElementById("check512_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check512_1ifyes").style.display="none";
	}}
function check513_1(){
	if(document.getElementById("check513_1").checked){
		document.getElementById("check513_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check513_1ifyes").style.display="none";
	}}
		function FQUALIFI(){
	if(document.getElementById("FQUALIFIyesCheck1").checked){
		document.getElementById("FQUALIFIifYes1").style.display ="block";
	}
	else{
		document.getElementById("FQUALIFIifYes1").style.display ="none";
	}}
	function check521_1(){
	if(document.getElementById("check521_1").checked){
		document.getElementById("check521_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check521_1ifyes").style.display="none";
	}}
	function check522_1(){
	if(document.getElementById("check522_1").checked){
		document.getElementById("check522_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check522_1ifyes").style.display="none";
	}}
	function check523_1(){
	if(document.getElementById("check523_1").checked){
		document.getElementById("check523_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check523_1ifyes").style.display="none";
	}}
	
	function FTRAIN(){
	if(document.getElementById("FTRAINyesCheck1").checked){
		document.getElementById("FTRAINifYes1").style.display ="block";
	}
	else{
		document.getElementById("FTRAINifYes1").style.display ="none";
	}}
	function check53_1(){
	if(document.getElementById("check53_1").checked){
		document.getElementById("check53_1ifyes").style.display ="block";
	}
	else{
		document.getElementById("check53_1ifyes").style.display="none";
	}}
function check53_2(){
	if(document.getElementById("check53_2").checked){
		document.getElementById("check53_2ifyes").style.display ="block";
	}
	else{
		document.getElementById("check53_2ifyes").style.display="none";
	}}
	function check53_3(){
	if(document.getElementById("check53_3").checked){
		document.getElementById("check53_3ifyes").style.display ="block";
	}
	else{
		document.getElementById("check53_3ifyes").style.display="none";
	}}
	function RETENTION(){
	if(document.getElementById("RETENTIONyesCheck1").checked){
		document.getElementById("RETENTIONifYes1").style.display ="block";
	}
	else{
		document.getElementById("RETENTIONifYes1").style.display ="none";
	}}
	function FRESEARCH(){
	if(document.getElementById("FRESEARCHyesCheck1").checked){
		document.getElementById("FRESEARCHifYes1").style.display ="block";
	}
	else{
		document.getElementById("FRESEARCHifYes1").style.display ="none";
	}}
	function FIPR(){
	if(document.getElementById("FIPRyesCheck1").checked){
		document.getElementById("FIPRifYes1").style.display ="block";
	}
	else{
		document.getElementById("FIPRifYes1").style.display ="none";
	}}
	function check551_1(){
	if(document.getElementById("check551_1").checked){
		document.getElementById("check551_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check551_1ifyes").style.display="none";
	}}
	function check552_1(){
	if(document.getElementById("check552_1").checked){
		document.getElementById("check552_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check552_1ifyes").style.display="none";
	}}
	function check553_1(){
	if(document.getElementById("check553_1").checked){
		document.getElementById("check553_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check553_1ifyes").style.display="none";
	}}
	function FACULTYRD(){
	if(document.getElementById("FACULTYRDyesCheck1").checked){
		document.getElementById("FACULTYRDifYes1").style.display ="block";
	}
	else{
		document.getElementById("FACULTYRDifYes1").style.display ="none";
	}}
function check571_1(){
	if(document.getElementById("check571_1").checked){
		document.getElementById("check571_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check571_1ifyes").style.display="none";
	}}
	function check572_1(){
	if(document.getElementById("check572_1").checked){
		document.getElementById("check572_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check572_1ifyes").style.display="none";
	}}
	function check573_1(){
	if(document.getElementById("check573_1").checked){
		document.getElementById("check573_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check573_1ifyes").style.display="none";
	}}
	function OUTSIDE(){
	if(document.getElementById("OUTSIDEyesCheck1").checked){
		document.getElementById("OUTSIDEifYes1").style.display ="block";
	}
	else{
		document.getElementById("OUTSIDEifYes1").style.display ="none";
	}}
	/*CRITERION 5 ENDS HERE
	criterion 6 starts*/
	function CLSROOM(){
	if(document.getElementById("CLSROOMyesCheck1").checked){
		document.getElementById("CLSROOMifYes1").style.display ="block";
	}
	else{
		document.getElementById("CLSROOMifYes1").style.display ="none";
	}}

function check61_1(){
	if(document.getElementById("check61_1").checked){
		document.getElementById("check61_1ifyes").style.display ="block";
	}
	else{
		document.getElementById("check61_1ifyes").style.display="none";
	}}
function check61_2(){
	if(document.getElementById("check61_2").checked){
		document.getElementById("check61_2ifyes").style.display ="block";
	}
	else{
		document.getElementById("check61_2ifyes").style.display="none";
	}}
	function check61_3(){
	if(document.getElementById("check61_3").checked){
		document.getElementById("check61_3ifyes").style.display ="block";
	}
	else{
		document.getElementById("check61_3ifyes").style.display="none";
	}}
	function FACULTY(){
	if(document.getElementById("FACULTYyesCheck1").checked){
		document.getElementById("FACULTYifYes1").style.display ="block";
	}
	else{
		document.getElementById("FACULTYifYes1").style.display ="none";
	}}

function check62_1(){
	if(document.getElementById("check62_1").checked){
		document.getElementById("check62_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check62_1ifyes").style.display="none";
	}}
function check62_2(){
	if(document.getElementById("check62_2").checked){
		document.getElementById("check62_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check62_2ifyes").style.display="none";
	}}
	function check62_3(){
	if(document.getElementById("check62_3").checked){
		document.getElementById("check62_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check62_3ifyes").style.display="none";
	}}
	function LAB(){
	if(document.getElementById("LAByesCheck1").checked){
		document.getElementById("LABifYes1").style.display ="block";
	}
	else{
		document.getElementById("LABifYes1").style.display ="none";
	}}

function check63_1(){
	if(document.getElementById("check63_1").checked){
		document.getElementById("check63_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check63_1ifyes").style.display="none";
	}}
function check63_2(){
	if(document.getElementById("check63_2").checked){
		document.getElementById("check63_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check63_2ifyes").style.display="none";
	}}
	function check63_3(){
	if(document.getElementById("check63_3").checked){
		document.getElementById("check63_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check63_3ifyes").style.display="none";
	}}
	function check63_4(){
	if(document.getElementById("check63_4").checked){
		document.getElementById("check63_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check63_4ifyes").style.display="none";
	}}
	function TECHNICAL(){
	if(document.getElementById("TECHNICALyesCheck1").checked){
		document.getElementById("TECHNICALifYes1").style.display ="block";
	}
	else{
		document.getElementById("TECHNICALifYes1").style.display ="none";
	}}

function check64_1(){
	if(document.getElementById("check64_1").checked){
		document.getElementById("check64_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check64_1ifyes").style.display="none";
	}}
function check64_2(){
	if(document.getElementById("check64_2").checked){
		document.getElementById("check64_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check64_2ifyes").style.display="none";
	}}
	/*CRITERION 7 STARTS FROM HERE*/
	function ACADEMIC(){
	if(document.getElementById("ACADEMICyesCheck1").checked){
		document.getElementById("ACADEMICifYes1").style.display ="block";
	}
	else{
		document.getElementById("ACADEMICifYes1").style.display ="none";
	}}

function check71_1(){
	if(document.getElementById("check71_1").checked){
		document.getElementById("check71_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check71_1ifyes").style.display="none";
	}}
function check71_2(){
	if(document.getElementById("check71_2").checked){
		document.getElementById("check71_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check71_2ifyes").style.display="none";
	}}
	function check71_3(){
	if(document.getElementById("check71_3").checked){
		document.getElementById("check71_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check71_3ifyes").style.display="none";
	}}
	function ASUCF(){
	if(document.getElementById("ASUCFyesCheck1").checked){
		document.getElementById("ASUCFifYes1").style.display ="block";
	}
	else{
		document.getElementById("ASUCFifYes1").style.display ="none";
	}}
	function check72_1(){
	if(document.getElementById("check72_1").checked){
		document.getElementById("check72_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check72_1ifyes").style.display="none";
	}}

	function check72_2(){
	if(document.getElementById("check72_2").checked){
		document.getElementById("check72_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check72_2ifyes").style.display="none";
	}}
	function check72_3(){
	if(document.getElementById("check72_3").checked){
		document.getElementById("check72_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check72_3ifyes").style.display="none";
	}}
	function check72_4(){
	if(document.getElementById("check72_4").checked){
		document.getElementById("check72_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check72_4ifyes").style.display="none";
	}}
	function TUTORIAL(){
	if(document.getElementById("TUTORIALyesCheck1").checked){
		document.getElementById("TUTORIALifYes1").style.display ="block";
	}
	else{
		document.getElementById("TUTORIALifYes1").style.display ="none";
	}}
	function check73_1(){
	if(document.getElementById("check73_1").checked){
		document.getElementById("check73_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check73_1ifyes").style.display="none";
	}}

	function check73_2(){
	if(document.getElementById("check73_2").checked){
		document.getElementById("check73_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check73_2ifyes").style.display="none";
	}}
	function check73_3(){
	if(document.getElementById("check73_3").checked){
		document.getElementById("check73_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check73_3ifyes").style.display="none";
	}}
	function TPSL(){
	if(document.getElementById("TPSLyesCheck1").checked){
		document.getElementById("TPSLifYes1").style.display ="block";
	}
	else{
		document.getElementById("TPSLifYes1").style.display ="none";
	}}
	function check74_1(){
	if(document.getElementById("check74_1").checked){
		document.getElementById("check74_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check74_1ifyes").style.display="none";
	}}

	function check74_2(){
	if(document.getElementById("check74_2").checked){
		document.getElementById("check74_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check74_2ifyes").style.display="none";
	}}
	function check74_3(){
	if(document.getElementById("check74_3").checked){
		document.getElementById("check74_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check74_3ifyes").style.display="none";
	}}
	function check74_4(){
	if(document.getElementById("check74_4").checked){
		document.getElementById("check74_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check74_4ifyes").style.display="none";
	}}
	function check74_5(){
	if(document.getElementById("check74_5").checked){
		document.getElementById("check74_5ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check74_5ifyes").style.display="none";
	}}
	function FEEDBACK(){
	if(document.getElementById("FEEDBACKyesCheck1").checked){
		document.getElementById("FEEDBACKifYes1").style.display ="block";
	}
	else{
		document.getElementById("FEEDBACKifYes1").style.display ="none";
	}}
	function check75_1(){
	if(document.getElementById("check75_1").checked){
		document.getElementById("check75_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check75_1ifyes").style.display="none";
	}}

	function check75_2(){
	if(document.getElementById("check75_2").checked){
		document.getElementById("check75_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check75_2ifyes").style.display="none";
	}}
	function check75_3(){
	if(document.getElementById("check75_3").checked){
		document.getElementById("check75_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check75_3ifyes").style.display="none";
	}}
function IPL(){
	if(document.getElementById("IPLyesCheck1").checked){
		document.getElementById("IPLifYes1").style.display ="block";
	}
	else{
		document.getElementById("IPLifYes1").style.display ="none";
	}}
	function check76_1(){
	if(document.getElementById("check76_1").checked){
		document.getElementById("check76_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check76_1ifyes").style.display="none";
	}}

	function check76_2(){
	if(document.getElementById("check76_2").checked){
		document.getElementById("check76_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check76_2ifyes").style.display="none";
	}}
	function check76_3(){
	if(document.getElementById("check76_3").checked){
		document.getElementById("check76_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check76_3ifyes").style.display="none";
	}}
	function TPEC(){
	if(document.getElementById("TPECyesCheck1").checked){
		document.getElementById("TPECifYes1").style.display ="block";
	}
	else{
		document.getElementById("TPECifYes1").style.display ="none";
	}}
	function check77_1(){
	if(document.getElementById("check77_1").checked){
		document.getElementById("check77_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check77_1ifyes").style.display="none";
	}}

	function check77_2(){
	if(document.getElementById("check77_2").checked){
		document.getElementById("check77_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check77_2ifyes").style.display="none";
	}}
	function check77_3(){
	if(document.getElementById("check77_3").checked){
		document.getElementById("check77_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check77_3ifyes").style.display="none";
	}}

function COCURRI(){
	if(document.getElementById("COCURRIyesCheck1").checked){
		document.getElementById("COCURRIifYes1").style.display ="block";
	}
	else{
		document.getElementById("COCURRIifYes1").style.display ="none";
	}}
	function check78_1(){
	if(document.getElementById("check78_1").checked){
		document.getElementById("check78_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check78_1ifyes").style.display="none";
	}}

	function check78_2(){
	if(document.getElementById("check78_2").checked){
		document.getElementById("check78_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check78_2ifyes").style.display="none";
	}}
	function check78_3(){
	if(document.getElementById("check78_3").checked){
		document.getElementById("check78_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check78_3ifyes").style.display="none";
	}}
/*CRITERION 7 ENDS HERE*/
	/*CRITERION 8 STARTS FROM HERE*/
	function CAMPUS(){
	if(document.getElementById("CAMPUSyesCheck1").checked){
		document.getElementById("CAMPUSifYes1").style.display ="block";
	}
	else{
		document.getElementById("CAMPUSifYes1").style.display ="none";
	}}

function check81_1(){
	if(document.getElementById("check81_1").checked){
		document.getElementById("check81_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check81_1ifyes").style.display="none";
	}}
function check81_2(){
	if(document.getElementById("check81_2").checked){
		document.getElementById("check81_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check81_2ifyes").style.display="none";
	}}
	function check81_3(){
	if(document.getElementById("check81_3").checked){
		document.getElementById("check81_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check81_3ifyes").style.display="none";
	}}

	function OGT(){
	if(document.getElementById("OGTyesCheck1").checked){
		document.getElementById("OGTifYes1").style.display ="block";
	}
	else{
		document.getElementById("OGTifYes1").style.display ="none";
	}}

function check82_1(){
	if(document.getElementById("check82_1").checked){
		document.getElementById("check82_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check82_1ifyes").style.display="none";
	}}
function check82_2(){
	if(document.getElementById("check82_2").checked){
		document.getElementById("check82_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check82_2ifyes").style.display="none";
	}}
	function check82_3(){
	if(document.getElementById("check82_3").checked){
		document.getElementById("check82_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check82_3ifyes").style.display="none";
	}}
	function check82_4(){
	if(document.getElementById("check82_4").checked){
		document.getElementById("check82_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check82_4ifyes").style.display="none";
	}}

	function BUDGET(){
	if(document.getElementById("BUDGETyesCheck1").checked){
		document.getElementById("BUDGETifYes1").style.display ="block";
	}
	else{
		document.getElementById("BUDGETifYes1").style.display ="none";
	}}

function check83_1(){
	if(document.getElementById("check83_1").checked){
		document.getElementById("check83_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check83_1ifyes").style.display="none";
	}}
function check83_2(){
	if(document.getElementById("check83_2").checked){
		document.getElementById("check83_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check83_2ifyes").style.display="none";
	}}
	function check83_3(){
	if(document.getElementById("check83_3").checked){
		document.getElementById("check83_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check83_3ifyes").style.display="none";
	}}
	function PSBA(){
	if(document.getElementById("PSBAyesCheck1").checked){
		document.getElementById("PSBAifYes1").style.display ="block";
	}
	else{
		document.getElementById("PSBAifYes1").style.display ="none";
	}}

function check84_1(){
	if(document.getElementById("check84_1").checked){
		document.getElementById("check84_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check84_1ifyes").style.display="none";
	}}
function check84_2(){
	if(document.getElementById("check84_2").checked){
		document.getElementById("check84_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check84_2ifyes").style.display="none";
	}}
	function INTERNET(){
	if(document.getElementById("INTERNETyesCheck1").checked){
		document.getElementById("INTERNETifYes1").style.display ="block";
	}
	else{
		document.getElementById("INTERNETifYes1").style.display ="none";
	}}

function check86_1(){
	if(document.getElementById("check86_1").checked){
		document.getElementById("check86_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check86_1ifyes").style.display="none";
	}}
	function SNC(){
	if(document.getElementById("SNCyesCheck1").checked){
		document.getElementById("SNCifYes1").style.display ="block";
	}
	else{
		document.getElementById("SNCifYes1").style.display ="none";
	}}

function check87_1(){
	if(document.getElementById("check87_1").checked){
		document.getElementById("check87_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check87_1ifyes").style.display="none";
	}}
function check87_2(){
	if(document.getElementById("check87_2").checked){
		document.getElementById("check87_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check87_2ifyes").style.display="none";
	}}
	function check87_3(){
	if(document.getElementById("check87_3").checked){
		document.getElementById("check87_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check87_3ifyes").style.display="none";
	}}
function check87_4(){
	if(document.getElementById("check87_4").checked){
		document.getElementById("check87_4ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check87_4ifyes").style.display="none";
	}}
	function CEMC(){
	if(document.getElementById("CEMCyesCheck1").checked){
		document.getElementById("CEMCifYes1").style.display ="block";
	}
	else{
		document.getElementById("CEMCifYes1").style.display ="none";
	}}

function check88_1(){
	if(document.getElementById("check88_1").checked){
		document.getElementById("check88_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check88_1ifyes").style.display="none";
	}}
function check88_2(){
	if(document.getElementById("check88_2").checked){
		document.getElementById("check88_2ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check88_2ifyes").style.display="none";
	}}
	function check88_3(){
	if(document.getElementById("check88_3").checked){
		document.getElementById("check88_3ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check88_3ifyes").style.display="none";
	}}
	/*CRITERION 4*/
	function ADMISSION(){
	if(document.getElementById("ADMISSIONyesCheck1").checked){
		document.getElementById("ADMISSIONifYes1").style.display ="block";
	}
	else{
		document.getElementById("ADMISSIONifYes1").style.display ="none";
	}}
	/*CRITERION 9*/
	function IMPROVEMENT(){
	if(document.getElementById("IMPROVEMENTyesCheck1").checked){
		document.getElementById("IMPROVEMENTifYes1").style.display ="block";
	}
	else{
		document.getElementById("IMPROVEMENTifYes1").style.display ="none";
	}}
	function IMPROVEMENT2(){
	if(document.getElementById("IMPROVEMENT2yesCheck1").checked){
		document.getElementById("IMPROVEMENT2ifYes1").style.display ="block";
	}
	else{
		document.getElementById("IMPROVEMENT2ifYes1").style.display ="none";
	}}
	function IMPROVEMENT3(){
	if(document.getElementById("IMPROVEMENT3yesCheck1").checked){
		document.getElementById("IMPROVEMENT3ifYes1").style.display ="block";
	}
	else{
		document.getElementById("IMPROVEMENT3ifYes1").style.display ="none";
	}}
	function IMPROVEMENT4(){
	if(document.getElementById("IMPROVEMENT4yesCheck1").checked){
		document.getElementById("IMPROVEMENT4ifYes1").style.display ="block";
	}
	else{
		document.getElementById("IMPROVEMENT4ifYes1").style.display ="none";
	}}
	function IMPROVEMENT5(){
	if(document.getElementById("IMPROVEMENT5yesCheck1").checked){
		document.getElementById("IMPROVEMENT5ifYes1").style.display ="block";
	}
	else{
		document.getElementById("IMPROVEMENT5ifYes1").style.display ="none";
	}}
	function CEDU(){
	if(document.getElementById("CEDUyesCheck1").checked){
		document.getElementById("CEDUifYes1").style.display ="block";
	}
	else{
		document.getElementById("CEDUifYes1").style.display ="none";
	}}

function check96_1(){
	if(document.getElementById("check96_1").checked){
		document.getElementById("check96_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check96_1ifyes").style.display="none";
	}}
	function NEWF(){
	if(document.getElementById("NEWFyesCheck1").checked){
		document.getElementById("NEWFifYes1").style.display ="block";
	}
	else{
		document.getElementById("NEWFifYes1").style.display ="none";
	}}

function check97_1(){
	if(document.getElementById("check97_1").checked){
		document.getElementById("check97_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check97_1ifyes").style.display="none";
	}}
function OVERALL(){
	if(document.getElementById("OVERALLyesCheck1").checked){
		document.getElementById("OVERALLifYes1").style.display ="block";
	}
	else{
		document.getElementById("OVERALLifYes1").style.display ="none";
	}}

function check98_1(){
	if(document.getElementById("check98_1").checked){
		document.getElementById("check98_1ifyes").style.display ="block";
	}
	
	else{
		document.getElementById("check98_1ifyes").style.display="none";
	}}

