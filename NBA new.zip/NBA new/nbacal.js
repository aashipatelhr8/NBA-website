function myFunctionCA() {
  var a = document.getElementById("CAbg11").value;
  $("#LTPOutput11").text(a);
   var b = document.getElementById("CAbg12").value;
   $("#LTPOutput12").text(b);
   var c = document.getElementById("CAbg13").value;
  $("#LTPOutput13").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#LTPOutput").text(sum.toFixed(2));
   }
   /*programme educational objctive*/
   function myFunctionPEO() {
	
  var a = document.getElementById("PEO21").value;
  $("#PEOOutput21").text(a);
   var b = document.getElementById("PEO22").value;
   $("#PEOOutput22").text(b);
   var c = document.getElementById("PEO23").value;
  $("#PEOOutput23").text(c);
  var d = document.getElementById("PEO24").value;
  $("#PEOOutput24").text(d);
   var e= document.getElementById("PEO25").value;
   $("#PEOOutput25").text(e);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d)+
  parseFloat(e);
  $("#PEOOutput").text(sum.toFixed(2));
   }
   function myFunctionAPEO() {
	
  var a = document.getElementById("APEO31").value;
  $("#APEOOutput31").text(a);
   var b = document.getElementById("APEO32").value;
   $("#APEOOutput32").text(b);
  var sum= parseFloat(a)+parseFloat(b);
  $("#APEOOutput").text(sum.toFixed(2));
   }
   function myFunctionAAPEO() {
	
  var a = document.getElementById("AAPEO41").value;
  $("#AAPEOOutput41").text(a);
   var b = document.getElementById("AAPEO42").value;
   $("#AAPEOOutput42").text(b);
  var sum= parseFloat(a)+parseFloat(b);
  $("#AAPEOOutput").text(sum.toFixed(2));
   }
   function myFunctionIPEOR() {
	
  var a = document.getElementById("IPEOR51").value;
  $("#IPEOROutput51").text(a);
   var sum= parseFloat(a);
  $("#IPEOROutput").text(sum.toFixed(2));
   }
    function myFunctionDVOC() {
	
  var a = document.getElementById("DVOC21").value;
  $("#DVOCOutput21").text(a);
   var b = document.getElementById("DVOC22").value;
   $("#DVOCOutput22").text(b);
   var c = document.getElementById("DVOC23").value;
  $("#DVOCOutput23").text(c);
  var d = document.getElementById("DVOC24").value;
  $("#DVOCOutput24").text(d);
   var e= document.getElementById("DVOC25").value;
   $("#DVOCOutput25").text(e);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d)+
  parseFloat(e);
  $("#DVOCOutput").text(sum.toFixed(2));
   }

 function myFunctionAPO() {
	
  var a = document.getElementById("APO21").value;
  $("#APOOutput21").text(a);
   var b = document.getElementById("APO22").value;
   $("#APOOutput22").text(b);
   var c = document.getElementById("APO23").value;
  $("#APOOutput23").text(c);
  var d = document.getElementById("APO24").value;
  $("#APOOutput24").text(d);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d);
  $("#APOOutput").text(sum.toFixed(2));
   }
   function myFunctionEAPO() {
	
  var a = document.getElementById("EAPO21").value;
  $("#EAPOOutput21").text(a);
   var b = document.getElementById("EAPO22").value;
   $("#EAPOOutput22").text(b);
   var sum= parseFloat(a)+parseFloat(b);
  $("#EAPOOutput").text(sum.toFixed(2));
   }
   function myFunctionUEAPO() {
	
  var a = document.getElementById("UEAPO21").value;
  $("#UEAPOOutput21").text(a);
   var b = document.getElementById("UEAPO22").value;
   $("#UEAPOOutput22").text(b);
   var c = document.getElementById("UEAPO23").value;
  $("#UEAPOOutput23").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#UEAPOOutput").text(sum.toFixed(2));
   }
   /* CRITERION 3 STARTS*/
    function myFunctionCURRICULUM() {
	
  var a = document.getElementById("CURRICULUM21").value;
  $("#CURRICULUMOutput21").text(a);
   var b = document.getElementById("CURRICULUM22").value;
   $("#CURRICULUMOutput22").text(b);
   var c = document.getElementById("CURRICULUM23").value;
  $("#CURRICULUMOutput23").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#CURRICULUMOutput").text(sum.toFixed(2));
   }
   function myFunctionCURRICOMP() {
	
  var a = document.getElementById("CURRICOMP22").value;
  $("#CURRICOMPOutput22").text(a);
  var sum= parseFloat(a);
  $("#CURRICOMPOutput").text(sum.toFixed(2));
   }
     function myFunctionIII() {
	
  var a = document.getElementById("III23").value;
  $("#IIIOutput23").text(a);
  var sum= parseFloat(a);
  $("#IIIOutput").text(sum.toFixed(2));
   }
 function myFunctionCURRIDEVELOP() {
	
  var a = document.getElementById("CURRIDEVELOP21").value;
  $("#CURRIDEVELOPOutput21").text(a);
   var b = document.getElementById("CURRIDEVELOP22").value;
   $("#CURRIDEVELOPOutput22").text(b);
  var sum= parseFloat(a)+parseFloat(b);
  $("#CURRIDEVELOPOutput").text(sum.toFixed(2));
   }

 function myFunctionCOURSE() {
	
  var a = document.getElementById("COURSE25").value;
  $("#COURSEOutput25").text(a);
  var sum= parseFloat(a);
  $("#COURSEOutput").text(sum.toFixed(2));

   }
   /*CRITERION 4 STARTS HERE*/
   function myFunctionAINTAKE() {
	debugger;
  var a = document.getElementById("AINTAKE41").value;
   var b = document.getElementById("AINTAKE42").value;
   /*if(a<b){
   alert("admission intake cannot be greater than total seats");
   }*/
   var ab= (parseFloat(b)/parseFloat(a))*10;
   var c = document.getElementById("AINTAKE43").value;
   var d = document.getElementById("AINTAKE44").value;
   /*if(c<d){
   	alert("admission intake cannot be greater than total seats");
   }*/
   var cd= (parseFloat(d)/parseFloat(c))*10;
   var e = document.getElementById("AINTAKE45").value;
   var f = document.getElementById("AINTAKE46").value;
   /*if(e<f){
   alert("admission intake cannot be greater than total seats");
   }*/
   var ef= (parseFloat(f)/parseFloat(e))*10;
  var sum= (parseFloat(ab)+parseFloat(cd)+parseFloat(ef))/3;
  $("#AINTAKEOutput").text(sum.toFixed(2));
  }
  function AQUALITY() {
  var a = document.getElementById("AQUALITY41").value;
  var b = document.getElementById("AQUALITY42").value;
  var ab= (parseFloat(b)/parseFloat(a))*10;
  var c = document.getElementById("AQUALITY43").value;
  var d = document.getElementById("AQUALITY44").value;
  var cd= (parseFloat(d)/parseFloat(c))*10;
  var e = document.getElementById("AQUALITY45").value;
  var f = document.getElementById("AQUALITY46").value;
  var ef= (parseFloat(f)/parseFloat(e))*10;
  var per=1.5*((parseFloat(ab)+parseFloat(cd)+parseFloat(ef))/3);
  $("#AQUALITYOutput").text(per.toFixed(2));
  }
  
   function SR() {
 var a = document.getElementById("SR41").value;
 var b = document.getElementById("SR42").value;
 var ab= (parseFloat(a)/parseFloat(b));
 var c = document.getElementById("SR43").value;
 var d = document.getElementById("SR44").value;
 var cd= (parseFloat(c)/parseFloat(d));
 var e = document.getElementById("SR45").value;
 var f = document.getElementById("SR46").value;
 var ef= (parseFloat(e)/parseFloat(f));
 var sum= 20*((parseFloat(ab)+parseFloat(cd)+parseFloat(ef))/3);
 $("#SROutput").text(sum.toFixed(2));
 if(sum>=0&&sum<5)
 $("#IMPROVEINSI").text("1");
 else if(sum>4&&sum<=8)
 $("#IMPROVEINSI").text("2");
 else if(sum>8&&sum<=12)
 $("#IMPROVEINSI").text("3");
 else if(sum>12&&sum<=16)
 $("#IMPROVEINSI").text("4");
 else
 $("#IMPROVEINSI").text("5");
 }

  function APERFORMANCE() {
	var a = document.getElementById("MEAN1").value;
  var api1= (2*(parseFloat(a)));
  /*if(a>10){
   alert("Mean of cgpa cannot be greater than 10");
   }*/
  var b = document.getElementById("MEAN2").value;
  var api2= (2*(parseFloat(b)));
  /* if(b>10){
   alert("Mean of cgpa cannot be greater than 10");
   }*/
  var c = document.getElementById("MEAN3").value;
  var api3= (2*(parseFloat(c)));
  /* if(c>10){
   alert("Mean of cgpa cannot be greater than 10");
   }*/
  var api=(parseFloat(api1)+parseFloat(api2)+parseFloat(api3))/3;
  $("#APERFORMANCEOutput").text(api.toFixed(2));
  if(api>=0&&api<5)
 $("#IMPROVEINACADEMIC").text("1");
 else if(api>4&&api<=8)
 $("#IMPROVEINACADEMIC").text("2");
 else if(api>8&&api<=12)
 $("#IMPROVEINACADEMIC").text("3");
 else if(api>12&&api<=16)
 $("#IMPROVEINACADEMIC").text("4");
 else
 $("#IMPROVEINACADEMIC").text("5");
   }
 function myFunctionPLACEMENT() {
	
  var a = document.getElementById("X").value;
   var b = document.getElementById("Y").value;
   var c = document.getElementById("N").value;
  var sum= (20*(parseFloat(a)+(1.25*parseFloat(b)))/c);
  	$("#ASSESSMENTOutput").text(sum.toFixed(2));
   }
    function myFunctionPA() {
	
  var a = document.getElementById("PA41").value;
  $("#PAOutput41").text(a);
   var b = document.getElementById("PA42").value;
   $("#PAOutput42").text(b);
   var c = document.getElementById("PA43").value;
  $("#PAOutput43").text(c);
   var d = document.getElementById("PA44").value;
  $("#PAOutput44").text(d);
   var e = document.getElementById("PA45").value;
  $("#PAOutput45").text(e);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d)
  +parseFloat(e);
  $("#PAOutput").text(sum.toFixed(2));
   }
   /*CRITERION 4 ENDS HERE
   CRITERION 5 STARTS HERE*/
  function STR() {
	
  var a = document.getElementById("S2").value;
  var b = document.getElementById("S3").value;
  var c = document.getElementById("TFACULTY1").value;
  var str1=(parseFloat(a)+parseFloat(b))/c;
  var sum1= 30*(12/parseFloat(str1));
   var d = document.getElementById("S4").value;
  var e = document.getElementById("S5").value;
  var f = document.getElementById("TFACULTY2").value;
  var str2=(parseFloat(d)+parseFloat(e))/f;
  var sum2= 30*(12/parseFloat(str2));
   var g = document.getElementById("S6").value;
  var h= document.getElementById("S7").value;
  var i = document.getElementById("TFACULTY3").value;
  var str3=(parseFloat(g)+parseFloat(h))/i;
  var sum3= 30*(12/parseFloat(str3));
  var sum=(parseFloat(sum1)+parseFloat(sum2)+parseFloat(sum3))/3;
   $("#STROutput").text(sum.toFixed(2));
   if(sum>=0&&sum<=6)
 $("#IMPROVEINSTR").text("1");
 else if(sum>6&&sum<=12)
 $("#IMPROVEINSTR").text("2");
 else if(sum>12&&sum<=18)
 $("#IMPROVEINSTR").text("3");
 else if(sum>18&&sum<=24)
 $("#IMPROVEINSTR").text("4");
 else
 $("#IMPROVEINSTR").text("5");
   }
  function FQI() 
  {
  var a = document.getElementById("X1").value;
  var b = document.getElementById("Y1").value;
  var c = document.getElementById("Z1").value;
  var e = document.getElementById("A1").value;
  var f = document.getElementById("A2").value;
  var sum1=(parseFloat(e)+parseFloat(f));
  var fqi1= (((10*(parseFloat(a)))+(8*(parseFloat(b)))+(6*(parseFloat(c))))/
  parseFloat(sum1));
  var g = document.getElementById("X2").value;
  var h = document.getElementById("Y2").value;
  var i = document.getElementById("Z2").value;
  var j = document.getElementById("B1").value;
  var k = document.getElementById("B2").value;
  var sum2=(parseFloat(j)+parseFloat(k));
  var fqi2= (((10*(parseFloat(g)))+(8*(parseFloat(h)))+(6*(parseFloat(i))))/
  parseFloat(sum2));
  var l = document.getElementById("X3").value;
  var m = document.getElementById("Y3").value;
  var n = document.getElementById("Z3").value;
  var o = document.getElementById("C1").value;
  var p = document.getElementById("C2").value;
  var sum3=(parseFloat(o)+parseFloat(p));
  var fqi3= (((10*(parseFloat(l)))+(8*(parseFloat(m)))+(6*(parseFloat(n))))/
  parseFloat(sum3));
  var clc= (2*((parseFloat(fqi1))+parseFloat(fqi2)+parseFloat(fqi3))/3);
  $("#FQIOutput").text(clc.toFixed(2));
  if(clc>=0&&clc<5)
 $("#IMPROVEINFQ").text("1");
 else if(clc>4&&clc<=8)
 $("#IMPROVEINFQ").text("2");
 else if(clc>8&&clc<=12)
 $("#IMPROVEINFQ").text("3");
 else if(clc>12&&clc<=16)
 $("#IMPROVEINFQ").text("4");
 else
 $("#IMPROVEINFQ").text("5");
   }
   function FTRAINING() 
  {
  var a = document.getElementById("induction").value;
  var b = document.getElementById("d1").value;
  var c = document.getElementById("d2").value;
  var sum1=(parseFloat(b)+parseFloat(c));
  var ind=10*((parseFloat(a))/parseFloat(sum1));
  $("#FTRAININGOutput1").text(ind.toFixed(2));
  var d = document.getElementById("content").value;
  var e = document.getElementById("e1").value;
  var f = document.getElementById("e2").value;
  var sum2=(parseFloat(e)+parseFloat(f));
  var con=5*((parseFloat(d))/(3*parseFloat(sum2)));
  $("#FTRAININGOutput2").text(con.toFixed(2));
  var g = document.getElementById("modular").value;
  var h = document.getElementById("f1").value;
  var i = document.getElementById("f2").value;
  var sum3=(parseFloat(h)+parseFloat(i));
  var mod=5*((parseFloat(g))/parseFloat(sum3));
  $("#FTRAININGOutput3").text(mod.toFixed(2));
  var sum= parseFloat(ind)+parseFloat(con)+parseFloat(mod);
  $("#FTRAININGOutput").text(sum.toFixed(2));
   }
    function RETENTIONCAL() 
  {
  var a = document.getElementById("G1").value;
  var b = document.getElementById("G2").value;
  var c = document.getElementById("G3").value;
  var sum=(parseFloat(b)+parseFloat(c));
  var clc= (parseFloat(a)/parseFloat(sum));
  $("#RETENTIONOutput").text(clc.toFixed(2));
   }
    function RESEARCHCAL() 
  {
  var a = document.getElementById("H11").value;
  var b = document.getElementById("H12").value;
  var c = document.getElementById("H13").value;
  var sum1=(parseFloat(b)+parseFloat(c));
  var clc1= (parseFloat(a)/parseFloat(sum1));
  var d = document.getElementById("H14").value;
  var e = document.getElementById("H15").value;
  var f = document.getElementById("H16").value;
  var sum2=(parseFloat(e)+parseFloat(f));
  var clc2= (parseFloat(d)/parseFloat(sum2));
  var g = document.getElementById("H17").value;
  var h = document.getElementById("H18").value;
  var i = document.getElementById("H19").value;
  var sum3=(parseFloat(h)+parseFloat(i));
  var clc3= (parseFloat(g)/parseFloat(sum3));
  var clc=(parseFloat(clc1)+parseFloat(clc2)+parseFloat(clc3))/3; 
  $("#RESEARCHCALOutput").text(clc.toFixed(2));
   }
   function FIPRCAL() 
  {
  var a = document.getElementById("I1").value;
  var b = document.getElementById("I2").value;
  var c = document.getElementById("I3").value;
  var sum=(parseFloat(b)+parseFloat(c));
  var clc= (parseFloat(a)/parseFloat(sum));
  $("#FIPRCALOutput").text(clc.toFixed(2));
   }
   function FACULTYRND() 
  {
  var a = document.getElementById("N11").value;
  var b = document.getElementById("S11").value;
  var c = document.getElementById("P11").value;
  var d = document.getElementById("T11").value;
  var e = document.getElementById("R11").value;
  var f = document.getElementById("E11").value;
  var g = document.getElementById("F11").value;
  var sum1=(parseFloat(f)+parseFloat(g));
  var clc1= ((5*parseFloat(a))+(4*parseFloat(b))+(3*parseFloat(c))+(2*parseFloat(d))+
  (2*parseFloat(e)))/parseFloat(sum1);
  var h = document.getElementById("N11").value;
  var i = document.getElementById("S11").value;
  var j = document.getElementById("P11").value;
  var k = document.getElementById("T11").value;
  var l = document.getElementById("R11").value;
  var m = document.getElementById("E11").value;
  var n = document.getElementById("F11").value;
  var sum2=(parseFloat(m)+parseFloat(n));
  var clc2= ((5*parseFloat(h))+(4*parseFloat(i))+(3*parseFloat(j))+(2*parseFloat(k))+
  (2*parseFloat(l)))/parseFloat(sum2);
  var o = document.getElementById("N11").value;
  var p = document.getElementById("S11").value;
  var q = document.getElementById("P11").value;
  var r = document.getElementById("T11").value;
  var s = document.getElementById("R11").value;
  var t = document.getElementById("E11").value;
  var u = document.getElementById("F11").value;
  var sum3=(parseFloat(t)+parseFloat(u));
  var clc3= ((5*parseFloat(o))+(4*parseFloat(p))+(3*parseFloat(q))+(2*parseFloat(r))+
  (2*parseFloat(s)))/parseFloat(sum3);
  var clc=(parseFloat(clc1)+parseFloat(clc2)+parseFloat(clc3))/3;
   $("#FACULTYRNDOutput").text(clc.toFixed(2));
   }
   function OUTSIDECAL() 
  {
  var a = document.getElementById("J1").value;
  var b = document.getElementById("J2").value;
  var c = document.getElementById("J3").value;
  var sum=(parseFloat(b)+parseFloat(c));
  var clc= 2*(parseFloat(a)/parseFloat(sum));
  $("#OUTSIDECALOutput").text(clc.toFixed(2));
   }

   /*CRITERION 5 ENDS HERE
   CRITERION 6 STARTS HERE*/

function myFunctionCLASSROOM() {
	
  var a = document.getElementById("CLASSROOM61").value;
  $("#CLASSROOMOutput61").text(a);
  var b = document.getElementById("CLASSROOM62").value;
  $("#CLASSROOMOutput62").text(b);
  var c = document.getElementById("CLASSROOM63").value;
  $("#CLASSROOMOutput63").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#CLASSROOMOutput").text(sum.toFixed(2));
   }
   function myFunctionFACULTY() {
	
  var a = document.getElementById("FACULTY61").value;
  $("#FACULTYOutput61").text(a);
   var b = document.getElementById("FACULTY62").value;
   $("#FACULTYOutput62").text(b);
   var c = document.getElementById("FACULTY63").value;
  $("#FACULTYOutput63").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#FACULTYOutput").text(sum.toFixed(2));
   }
   function myFunctionLAB() {
	
  var a = document.getElementById("LAB61").value;
  $("#LABOutput61").text(a);
   var b = document.getElementById("LAB62").value;
   $("#LABOutput62").text(b);
   var c = document.getElementById("LAB63").value;
  $("#LABOutput63").text(c);
   var d = document.getElementById("LAB64").value;
  $("#LABOutput64").text(d);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d);
  $("#LABOutput").text(sum.toFixed(2));
   }
function myFunctionTECHNICAL() {
	
  var a = document.getElementById("TECHNICAL61").value;
  $("#TECHNICALOutput61").text(a);
   var b = document.getElementById("TECHNICAL62").value;
   $("#TECHNICALOutput62").text(b);
  var sum= parseFloat(a)+parseFloat(b);
  $("#TECHNICALOutput").text(sum.toFixed(2));
   }
   /*CRITERION 8*/
     function myFunctionCAMPUS() {
	
  var a = document.getElementById("CAMPUS81").value;
  $("#CAMPUSOutput81").text(a);
   var b = document.getElementById("CAMPUS82").value;
   $("#CAMPUSOutput82").text(b);
   var c = document.getElementById("CAMPUS83").value;
  $("#CAMPUSOutput83").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#CAMPUSOutput").text(sum.toFixed(2));
   }
   function myFunctionOGT() {
	
  var a = document.getElementById("OGT81").value;
  $("#OGTOutput81").text(a);
   var b = document.getElementById("OGT82").value;
   $("#OGTOutput82").text(b);
   var c = document.getElementById("OGT83").value;
  $("#OGTOutput83").text(c);
   var d = document.getElementById("OGT84").value;
  $("#OGTOutput84").text(d);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d);
  $("#OGTOutput").text(sum.toFixed(2));
   }

     function myFunctionBUDGET() {
	
  var a = document.getElementById("BUDGET81").value;
  $("#BUDGETOutput81").text(a);
   var b = document.getElementById("BUDGET82").value;
   $("#BUDGETOutput82").text(b);
   var c = document.getElementById("BUDGET83").value;
  $("#BUDGETOutput83").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#BUDGETOutput").text(sum.toFixed(2));
   }
    function myFunctionPSBA() {
	
  var a = document.getElementById("PSBA81").value;
  $("#PSBAOutput81").text(a);
   var b = document.getElementById("PSBA82").value;
   $("#PSBAOutput82").text(b);
  var sum= parseFloat(a)+parseFloat(b);
  $("#PSBAOutput").text(sum.toFixed(2));
   }
    function myFunctionINTERNET() {
	
  var a = document.getElementById("INTERNET81").value;
  $("#INTERNETOutput81").text(a);
  var sum= parseFloat(a);
  $("#INTERNETOutput").text(sum.toFixed(2));
   }
   function myFunctionSNC() {
	
  var a = document.getElementById("SNC81").value;
  $("#SNCOutput81").text(a);
   var b = document.getElementById("SNC82").value;
   $("#SNCOutput82").text(b);
   var c = document.getElementById("SNC83").value;
  $("#SNCOutput83").text(c);
   var d = document.getElementById("SNC84").value;
  $("#SNCOutput84").text(d);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d);
  $("#SNCOutput").text(sum.toFixed(2));
   }
   function myFunctionCEMC() {
	
  var a = document.getElementById("CEMC81").value;
  $("#CEMCOutput81").text(a);
   var b = document.getElementById("CEMC82").value;
   $("#CEMCOutput82").text(b);
   var c = document.getElementById("CEMC83").value;
  $("#CEMCOutput83").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#CEMCOutput").text(sum.toFixed(2));
   }
   /*CRITERION 7*/
 function myFunctionACADEMIC() {
	
  var a = document.getElementById("ACADEMIC71").value;
  $("#ACADEMICOutput71").text(a);
   var b = document.getElementById("ACADEMIC72").value;
   $("#ACADEMICOutput72").text(b);
   var c = document.getElementById("ACADEMIC73").value;
  $("#ACADEMICOutput73").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#ACADEMICOutput").text(sum.toFixed(2));
   }
function myFunctionASUCF() {
	
  var a = document.getElementById("ASUCF71").value;
  $("#ASUCFOutput71").text(a);
   var b = document.getElementById("ASUCF72").value;
   $("#ASUCFOutput72").text(b);
   var c = document.getElementById("ASUCF73").value;
  $("#ASUCFOutput73").text(c);
   var d = document.getElementById("ASUCF74").value;
  $("#ASUCFOutput74").text(d);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d);
  $("#ASUCFOutput").text(sum.toFixed(2));
   }
   function myFunctionTUTORIAL() {
	
  var a = document.getElementById("TUTORIAL71").value;
  $("#TUTORIALOutput71").text(a);
   var b = document.getElementById("TUTORIAL72").value;
   $("#TUTORIALOutput72").text(b);
   var c = document.getElementById("TUTORIAL73").value;
  $("#TUTORIALOutput73").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#TUTORIALOutput").text(sum.toFixed(2));
}
  function myFunctionTPCL() {
	
  var a = document.getElementById("TPCL71").value;
  $("#TPCLOutput71").text(a);
   var b = document.getElementById("TPCL72").value;
   $("#TPCLOutput72").text(b);
   var c = document.getElementById("TPCL73").value;
  $("#TPCLOutput73").text(c);
   var d = document.getElementById("TPCL74").value;
  $("#TPCLOutput74").text(d);
   var e = document.getElementById("TPCL75").value;
  $("#TPCLOutput75").text(e);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d)+parseFloat(e);
  $("#TPCLOutput").text(sum.toFixed(2));
   }
    function myFunctionFEEDBACK() {
	
  var a = document.getElementById("FEEDBACK71").value;
  $("#FEEDBACKOutput71").text(a);
   var b = document.getElementById("FEEDBACK72").value;
   $("#FEEDBACKOutput72").text(b);
   var c = document.getElementById("FEEDBACK73").value;
  $("#FEEDBACKOutput73").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#FEEDBACKOutput").text(sum.toFixed(2));
}
 function myFunctionIPL() {
	
  var a = document.getElementById("IPL71").value;
  $("#IPLOutput71").text(a);
   var b = document.getElementById("IPL72").value;
   $("#IPLOutput72").text(b);
   var c = document.getElementById("IPL73").value;
  $("#IPLOutput73").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#IPLOutput").text(sum.toFixed(2));
}
 function myFunctionTPEC() {
	
  var a = document.getElementById("TPEC71").value;
  $("#TPECOutput71").text(a);
   var b = document.getElementById("TPEC72").value;
   $("#TPECOutput72").text(b);
   var c = document.getElementById("TPEC73").value;
  $("#TPECOutput73").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#TPECOutput").text(sum.toFixed(2));
}
function myFunctionCOCURRI() {
	
  var a = document.getElementById("COCURRI71").value;
  $("#COCURRIOutput71").text(a);
   var b = document.getElementById("COCURRI72").value;
   $("#COCURRIOutput72").text(b);
   var c = document.getElementById("COCURRI73").value;
  $("#COCURRIOutput73").text(c);
  var sum= parseFloat(a)+parseFloat(b)+parseFloat(c);
  $("#COCURRIOutput").text(sum.toFixed(2));

}
/*CRITERION 9 STARTS*/
function myFunctionEDU() {
	
  var a = document.getElementById("EDU91").value;
  $("#EDUOutput91").text(a);
  var sum= parseFloat(a);
  $("#EDUOutput").text(sum.toFixed(2));

}
function myFunctionNEWF() {
	
  var a = document.getElementById("NEWF91").value;
  $("#NEWFOutput91").text(a);
  var sum= parseFloat(a);
  $("#NEWFOutput").text(sum.toFixed(2));

}
function myFunctionOVERALL() {
	
  var a = document.getElementById("OVERALL91").value;
  $("#OVERALLOutput91").text(a);
  var sum= parseFloat(a);
  $("#OVERALLOutput").text(sum.toFixed(2));
}
/*criterion 9 ends here*/
/*function myFunctiongrandtotal(){
var a=$("#NEWFOutput").text();
var b=$("#OVERALLOutput").text();
var c=$("#EDUOutput").text();
	
var grandtotal=parseFloat(a)+parseFloat(b)+parseFloat(c);
$("#grandtotalOutput").text(grandtotal.toFixed(2));
}*/

function myFunctiongrandtotal()
{
var a=$("#LTPOutput").text();
var b=$("#PEOOutput").text();
var c=$("#APEOOutput").text();
var d=$("#AAPEOOutput").text();
var e=$("#IPEOROutput").text();
var f=$("#DVOCOutput").text();
var g=$("#APOOutput").text();
var h=$("#EAPOOutput").text();
var i=$("#UEAPOOutput").text();
var j=$("#CURRICULUMOutput").text();
var k=$("#CURRICOMPOutput").text();
var l=$("#IIIOutput").text();
var m=$("#CURRIDEVELOPOutput").text();var n=$("#COURSEOutput").text();
var o=$("#AINTAKEOutput").text();
var p=$("#AQUALITYOutput").text();
var q=$("#SROutput").text();
var r=$("#APERFORMANCEOutput").text();
var s=$("#ASSESSMENTOutput").text();
var t=$("#PAOutput").text();var u=$("#STROutput").text();
var v=$("#FQIOutput").text();var w=$("#FTRAININGOutput").text();
var x=$("#RETENTIONOutput").text();
var y=$("#RESEARCHCALOutput").text();var z=$("#FIPRCALOutput").text();
var a1=$("#FACULTYRNDOutput").text();
var b1=$("#OUTSIDECALOutput").text();var c1=$("#CLASSROOMOutput").text();
var d1=$("#FACULTYOutput").text();var e1=$("#LABOutput").text();
var f1=$("#CAMPUSOutput").text();
var g1=$("#OGTOutput").text();var h1=$("#BUDGETOutput").text();
var i1=$("#PSBAOutput").text();
var j1=$("#INTERNETOutput").text();var k1=$("#SNCOutput").text();
var l1=$("#CEMCOutput").text();
var m1=$("#ACADEMICOutput").text();var n1=$("#ASUCFOutput").text();
var o1=$("#TUTORIALOutput").text();
var p1=$("#TPCLOutput").text();var q1=$("#FEEDBACKOutput").text();
var r1=$("#IPLOutput").text();
var s1=$("#TPECOutput").text();var t1=$("#COCURRIOutput").text();
var u1=$("#EDUOutput").text();
var v1=$("#NEWFOutput").text();var w1=$("#OVERALLOutput").text();
var x1=$("#IMPROVEINSI").text();var y1=$("#IMPROVEINACADEMIC").text();
var z1=$("#IMPROVEINSTR").text();var a11=$("#IMPROVEINFQ").text();

var grandtotal= parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d)+ parseFloat(e)
+parseFloat(f)+parseFloat(g)+parseFloat(h)+parseFloat(i)+parseFloat(j)
+parseFloat(k)+parseFloat(l)+parseFloat(m)+parseFloat(n)+parseFloat(o)
+parseFloat(p)+parseFloat(q)+parseFloat(r)+parseFloat(s)+parseFloat(t)
+parseFloat(u)+parseFloat(v)+parseFloat(w)+parseFloat(x)+parseFloat(y)+parseFloat(z)
+parseFloat(a1)+parseFloat(b1)+parseFloat(c1)+parseFloat(d1)+ parseFloat(e1)
+parseFloat(f1)+parseFloat(g1)+parseFloat(h1)+parseFloat(i1)+parseFloat(j1)
+parseFloat(k1)+parseFloat(l1)+parseFloat(m1)+parseFloat(n1)+parseFloat(o1)
+parseFloat(p1)+parseFloat(q1)+parseFloat(r1)+parseFloat(s1)+parseFloat(t1)
+parseFloat(u1)+parseFloat(v1)+parseFloat(w1)+parseFloat(x1)+parseFloat(y1)
+parseFloat(z1)+parseFloat(a11);
$("#grandtotalOutput").text(grandtotal.toFixed(2));
}